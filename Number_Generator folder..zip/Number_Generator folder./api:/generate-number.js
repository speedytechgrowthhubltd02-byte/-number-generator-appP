import twilio from "twilio";

export default async function handler(req,res){
  const { country } = req.body;
  if(!country) return res.status(400).json({error:"Country not specified"});
  try{
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    const number = await client.incomingPhoneNumbers.create({smsEnabled:true,voiceEnabled:false});
    const verificationCode=Math.floor(100000+Math.random()*900000);
    await client.messages.create({body:`Your code: ${verificationCode}`,from:number.phoneNumber,to:number.phoneNumber});
    res.status(200).json({number:number.phoneNumber,message:"Real number assigned. Code sent!",code:verificationCode});
  }catch(err){res.status(500).json({error:err.message});}
}