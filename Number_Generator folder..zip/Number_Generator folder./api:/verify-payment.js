export default async function handler(req,res){
  const { txHash,currency } = req.body;
  if(!txHash||!currency) return res.status(400).json({success:false,message:"Missing parameters"});
  try{
    // Simulate verification, replace with real blockchain API
    const isValidPayment=true;
    if(isValidPayment) res.status(200).json({success:true,message:"Payment verified!"});
    else res.status(200).json({success:false,message:"Payment invalid"});
  }catch(err){res.status(500).json({success:false,message:err.message});}
}