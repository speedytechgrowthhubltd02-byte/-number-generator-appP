// Wallet copy
function copyWallet(id) {
  const wallet = document.getElementById(id).innerText;
  navigator.clipboard.writeText(wallet).then(() => alert("📋 Wallet copied!"));
}

// Dark mode
document.getElementById("darkToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("darkMode", document.body.classList.contains("dark"));
});

// Detect system dark mode
const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
if (localStorage.getItem("darkMode") === null) {
  if (prefersDark) { document.body.classList.add("dark"); localStorage.setItem("darkMode","true"); }
  else { document.body.classList.remove("dark"); localStorage.setItem("darkMode","false"); }
}

// Generate QR Codes
function generateWalletQRCodes() {
  new QRCode(document.getElementById("btcQR"), document.getElementById("btcWallet").innerText);
  new QRCode(document.getElementById("ethQR"), document.getElementById("ethWallet").innerText);
  new QRCode(document.getElementById("usdtQR"), document.getElementById("usdtWallet").innerText);
}

// Confetti
function launchConfetti() { confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } }); }

// Payment verification
async function verifyPayment() {
  const txHash = document.getElementById("txHash").value.trim();
  const currency = document.getElementById("currency").value;
  if(!txHash){ alert("⚠️ Enter transaction hash"); return; }
  try {
    const res = await fetch("/api/verify-payment", {
      method:"POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({txHash,currency})
    });
    const data = await res.json();
    if(data.success){
      alert("✅ Payment confirmed!");
      localStorage.setItem("paymentConfirmed","true");
      document.getElementById("paymentSection").style.display="none";
      document.getElementById("numberSection").style.display="block";
      new Audio("success.mp3").play();
      launchConfetti();
    }else{ alert("❌ "+data.message); }
  } catch(err){ alert("Error: "+err.message); }
}

// Generate number
async function generateNumber(country){
  try{
    const res = await fetch("/api/generate-number",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({country})});
    const data = await res.json();
    const resultDiv = document.getElementById("result");
    resultDiv.innerText=`📞 Number: ${data.number}\nMessage: ${data.message}`;
    resultDiv.classList.remove("show"); void resultDiv.offsetWidth; resultDiv.classList.add("show");
    new Audio("success.mp3").play(); launchConfetti();

    const historyList = document.getElementById("history");
    const li = document.createElement("li");
    li.innerText=`${new Date().toLocaleString()} - ${data.number}`;
    li.classList.add("new-history-item");
    historyList.prepend(li);
    li.addEventListener("animationend",()=>{li.classList.remove("new-history-item");});

    let history = JSON.parse(localStorage.getItem("history")||"[]");
    history.unshift({number:data.number,time:new Date().toISOString()});
    localStorage.setItem("history",JSON.stringify(history));

  }catch(err){ alert("Error: "+err.message); }
}

// Restore history + settings
window.onload = ()=>{
  generateWalletQRCodes();
  if(localStorage.getItem("paymentConfirmed")==="true"){ document.getElementById("paymentSection").style.display="none"; document.getElementById("numberSection").style.display="block"; }
  const history=JSON.parse(localStorage.getItem("history")||"[]");
  const historyList=document.getElementById("history");
  history.forEach(item=>{const li=document.createElement("li"); li.innerText=`${new Date(item.time).toLocaleString()} - ${item.number}`; historyList.appendChild(li); });
};